import tkinter as tk
from tkinter import *
import random

'''
@Row 为高方向的单元数
@Column 为长方向上的单元数
@Unit_size 为单个单元的边长
@Height 为整体的高度
@Width 为整体的长度
'''
global Row, Column
Row = 20
Column = 20
Unit_size = 20
Height = Row * Unit_size
Width = Column * Unit_size
global Direction
Direction = 2
global FPS
FPS = 150
global Have_food
Have_food = 0
global Food_coord
Food_coord = [0, 0]
global Score
Score = 0
global snake_list
snake_list = [[11, 10], [10, 10], [9, 10]]
global game_map
game_map = []


# Dire为前进方向全局变量-1，1，-2，2代表Up，Down，Left，Right
def draw_a_unit(canvas, col, row, unit_color="green"):
    # 画一个以左上角为参照的（c， r）的方块
    x1 = col * Unit_size
    y1 = row * Unit_size
    # 设置屏幕大小，宽和高，高度留出俩格用于显示分数
    x2 = (col + 1) * Unit_size
    y2 = (row + 1) * Unit_size
    # 用画布对象中的组件进行绘画，从(x0, y0)到（x1, y1)对角线构成的矩形
    canvas.create_rectangle(x1, y1, x2, y2, fill=unit_color, outline="white")


def put_a_backgroud(canvas, color='silver'):
    # 画布上构建像素网格
    for x in range(Column):
        for y in range(Row):
            draw_a_unit(canvas, x, y, unit_color=color)
            game_map.append([x, y])


def draw_the_snake(canvas, snake_list, color='green'):
    '''
    @description: 画蛇函数
    @param {type} snake_list为整数列表，默认元素为列表[x, y]
    @return: None
    '''
    for i in snake_list:
        draw_a_unit(canvas, i[0], i[1], unit_color=color)


def snake_move(snake_list, dire):
    # 通过event的外部事件绑定实现对direction的改变
    # 或者默认方向调用实现
    # return 新的snake_list
    global Row, Column
    global Have_food
    global Food_coord
    global Score
    new_coord = [0, 0]
    if dire % 2 == 1:
        new_coord[0] = snake_list[0][0]
        new_coord[1] = snake_list[0][1] + dire
    else:
        new_coord[0] = snake_list[0][0] + (int)(dire / 2)
        new_coord[1] = snake_list[0][1]
    snake_list.insert(0, new_coord)
    # 进行一个取模处理，形成穿越边界的效果
    for coord in snake_list:
        if coord[0] not in range(Column):
            coord[0] %= Column
            break
        elif coord[1] not in range(Row):
            coord[1] %= Row
            break
    if snake_list[0] == Food_coord:
        draw_a_unit(canvas, snake_list[0][0], snake_list[0][1], )
        Have_food = 0
        Score += 10
        str_score.set('得分:' + str(Score))
    else:

        draw_a_unit(canvas, snake_list[-1][0], snake_list[-1][1], unit_color="silver")
        draw_a_unit(canvas, snake_list[0][0], snake_list[0][1], )
        snake_list.pop()
    return snake_list


# 保证蛇头不可以朝原有的蛇的方向前进，event为绑定的键盘鼠标事件
def callback(event):
    # 判断是否可以向上向下操作
    global Direction
    ch = event.keysym
    if ch == 'Up':
        if snake_list[0][0] != snake_list[1][0]:
            Direction = -1
    elif ch == 'Down':
        if snake_list[0][0] != snake_list[1][0]:
            Direction = 1
    elif ch == 'Left':
        if snake_list[0][1] != snake_list[1][1]:
            Direction = -2
    elif ch == 'Right':
        if snake_list[0][1] != snake_list[1][1]:
            Direction = 2
    return


# 判断当前状态下蛇是否撞上自己
def snake_death_judge(snake_list):
    # return 0代表没有死亡
    # return 1代表死亡
    # 涉及列表查重的方法
    set_list = snake_list[1:]
    if snake_list[0] in set_list:
        return 1
    else:
        return 0


def food(canvas, snake_list):
    # 随机生成位置(x1, y1)
    global Column, Row, Have_food, Food_coord
    global game_map
    if Have_food:
        return
    # 碰撞检测，判断是否吃到了食物
    Food_coord[0] = random.choice(range(Column))
    Food_coord[1] = random.choice(range(Row))
    while Food_coord in snake_list:
        Food_coord[0] = random.choice(range(Column))
        Food_coord[1] = random.choice(range(Row))
    draw_a_unit(canvas, Food_coord[0], Food_coord[1], unit_color='red')
    Have_food = 1


move_able = True


def game_loop():
    global FPS
    global snake_list

    win.update()
    food(canvas, snake_list)

    if move_able:
        snake_list = snake_move(snake_list, Direction)

    flag = snake_death_judge(snake_list)
    # 设置游戏结束界面
    if flag:
        root = Tk()
        over_lavel = tk.Label(win, text='游戏结束', font=('楷体', 25), width=15, height=1)
        over_lavel.place(x=40, y=Height / 2, bg=None)
        # 通过输入框获取玩家姓名
        Label(root, text="请输入你的大名：").grid(row=0)
        v = StringVar()
        e = Entry(root)
        e.grid(row=0, column=1, padx=10, pady=5)

        # 显示分数排名
        def show():
            name = e.get()
            print("    高分排行榜")
            print("姓名        得分")

            print(name+"          "+str(Score))
        # 添加俩个按钮
        Button(root, text="低调离开", width=10, command=quit) \
            .grid(row=2, column=0, sticky=W, padx=10, pady=5)
        Button(root, text="确定", width=10, command=show) \
            .grid(row=2, column=1, sticky=E, padx=10, pady=5)

        return

    win.after(FPS, game_loop)


from time import sleep
stop = False

# 设置暂停功能
def do_stop(event):
    if event.keycode == 27:     # ESC键暂停
        global move_able
        global stop
        move_able = False
        stop = True
        def start(event):
            global move_able
            global stop
            print(f"事件触发键盘输入:{event.char},对应的ASCII码:{event.keycode}")

            if event.keycode == 27 and stop:
                stop = False
                move_able = True
                print("start")

        canvas.bind("<Key>", start)

        while stop:
            print(stop)
            sleep(0.05)
            win.update()






## 导入以上为所有函数

win = tk.Tk()
win.title('贪吃蛇')
canvas = tk.Canvas(win, width=Width, height=Height + 2 * Unit_size)
canvas.pack()
str_score = tk.StringVar()
score_label = tk.Label(win, textvariable=str_score, font=('楷体', 20), width=15, height=1)

# 显示时刻的分数

str_score.set('得分:' + str(Score))
score_label.place(x=80, y=Height)
put_a_backgroud(canvas)
draw_the_snake(canvas, snake_list)
# 绑定键盘鼠标事件关系
canvas.focus_set()
canvas.bind("<KeyPress-Left>", callback)
canvas.bind("<KeyPress-Right>", callback)
canvas.bind("<KeyPress-Up>", callback)
canvas.bind("<KeyPress-Down>", callback)
# canvas.bind("<Key>", do_stop)
# 游戏进程代码
game_loop()


while True:
    if not stop:
        win.update()
        canvas.bind("<Key>", do_stop)
    else:
        sleep(0.02)

